/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpsystem;

/**
 *
 * @author sandeep
 */
public class previous {
    private String a;
    private String b;
    private String c;
    private String d;
    private String e;
    private String f;
    private String g;
    private String h;
    private String i;
    private String j;
    private String k;
    private String l;
    private String m;
    private String n;
    private String o;
    private String p;
    
    public previous(String A,String B,String C,String D,String E,String F,String G,String H,String I,String J,String K,String L,String M,String N,String O,String P)
    {
        this.a=A;
        this.b=B;
        this.c=C;
       this.d=D;
       this.e=E;
       this.f=F;
       this.g=G;
       this.i=I;
       this.j=J;
       this.k=K;
       this.l=L;
       this.m=M;
       this.n=N;
       this.o=O;
       this.p=P;
    }
     public String a()
    {
        return a;
    }
     public String b()
    {
        return b;
    }
     public String c()
    {
        return c;
    }
     public String d()
    {
        return d;
    }
     public String e()
    {
        return e;
    }
      public String f()
    {
        return f;
    }
       public String g()
    {
        return g;
    }
        public String h()
    {
        return h;
    }
         public String i()
    {
        return i;
    }
          public String j()
    {
        return j;
    }
           public String k()
    {
        return k;
    }
            public String l()
    {
        return l;
    }
             public String m()
    {
        return m;
    }
              public String n()
    {
        return n;
    }
               public String o()
    {
        return o;
    }
                public String p()
    {
        return p;
    }
}
