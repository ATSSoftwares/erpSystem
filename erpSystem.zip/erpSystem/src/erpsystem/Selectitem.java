/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpsystem;
/**
 *
 * @author sandeep
 */
public class Selectitem {
     private String type;
    private String company;
   
    private String model;
     private String price;
     private String stock;
   
    
    public  Selectitem( String Type,String Company, String Model,String Price, String Stock)
    {
        
        this.type=Type;
       this.company=Company;
         this.model=Model;
         this.price=Price;
        this.stock=Stock;
    }
    
    
    
    public String getType()
    {
        return type;
    }
    
   public String getCompany()
    {
      return company;  
    }
   
    
    public String getModel()
    {
      return model;  
    }
    public String getPrice()
    {
      return price;  
    }
    public String getStock()
    {
      return stock;  
    }
    
   
    
    
}
