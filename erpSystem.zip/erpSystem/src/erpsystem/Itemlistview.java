/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpsystem;
/**
 *
 * @author sandeep
 */
public class Itemlistview {
     private String type;
   
   
    private String company;
    private String model;
    private String sale;
    private String stock;
    
    
    
    public Itemlistview(String Type, String Comp, String Model, String Sale,String Stock)
    {
        
        this.type=Type;
       
        this.company=Comp;
        this.model=Model;
        this.sale=Sale;
        this.stock=Stock;
    }
    
    
     public String getType()
    {
      return type;  
    }
    public String getCompay()
    {
      return company;  
    }
    
    public String getModel()
    {
        return model;
    }
    
   
   
    
    public String getSale()
    {
      return sale;  
    }
    
   public String getStock()
   {
       return stock;
   }

   
    
}
