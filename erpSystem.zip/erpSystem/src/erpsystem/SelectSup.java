/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpsystem;
/**
 *
 * @author sandeep
 */
public class SelectSup {
      private String name;
    private String address;
   
    private String city;
     private String pin;
    private String contact;
    private String contact2;
  //   private String email;
    
    public SelectSup( String Name,String Add, String City,String Pin, String Contact,String Contact2)
    {
        
        this.name=Name;
       this.address=Add;
         this.city=City;
         this.pin=Pin;
        this.contact=Contact;
        this.contact2=Contact2;
//      this.email=Em;
    }
    
    
    
    public String getName()
    {
        return name;
    }
    
   public String getAdd()
    {
      return address;  
    }
   
    
    public String getCity()
    {
      return city;  
    }
    public String getPin()
    {
      return pin;  
    }
    
    public String getContact()
    {
      return contact;  
    }
    public String getContact2()
    {
      return contact2;  
    }
//    public String getEmail()
//    {
//      return email;  
//    }
}
