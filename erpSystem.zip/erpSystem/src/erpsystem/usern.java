/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpsystem;

/**
 *
 * @author sandeep
 */
public class usern {
    private String user;
    public usern(String User)
    {
        this.user=User;
    }
    public String uname()
    {
        return user;
    }
}
