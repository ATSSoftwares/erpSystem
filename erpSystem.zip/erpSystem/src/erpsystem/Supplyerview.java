/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpsystem;
/**
 *
 * @author sandeep
 */
public class Supplyerview {
    private String name;
   
   
    private String city;
    private String contact;
    private String contact2;
    
    
    public Supplyerview( String Name, String City, String Contact,String Contact2)
    {
        
        this.name=Name;
       
         this.city=City;
        this.contact=Contact;
        this.contact2=Contact2;
    }
    
    
    
    public String getName()
    {
        return name;
    }
    
   
   
    
    public String getCity()
    {
      return city;  
    }
    
    public String getContact()
    {
      return contact;  
    }
    public String getContact2()
    {
      return contact2;  
    }

   
    
}
