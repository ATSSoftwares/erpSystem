/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpsystem;
/**
 *
 * @author sandeep
 */
public class Selecteditems2 {
    private String type;
    private String company;
   
    private String model;
     private String srate;
   private String prate;
   private String qunt;
   private String total;
   
    public  Selecteditems2(String Type,String Company,String Model,String Srate,String Prate,String Qunt,String Total)
    {
        
        this.type=Type;
       this.company=Company;
         this.model=Model;
         this.srate=Srate;
          this.prate=Prate;
           this.qunt=Qunt;
         this.total=Total;
    }
     public String getType()
    {
        return type;
    }
      public String getComp()
    {
        return company;
    }
       public String getModel()
    {
        return model;
    } public String getSrate()
    {
        return srate;
    } public String getPrate()
    {
        return prate;
    } public String getQunt()
    {
        return qunt;
    } public String getTotal()
    {
        return total;
    }
    
    
    
    
       
   
}
