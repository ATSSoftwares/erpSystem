package erpsystem;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sandeep
 */
public class Validation {
    public static boolean email_Validation(String email)
    {
        boolean status=false;
        String email_pattern="'!', '#', '$', '%', '^', '&', '*', '(', ')', '-', '/', '~', '[', ']'";
        Pattern pattern=Pattern.compile(email_pattern);
        Matcher matcher=pattern.matcher(email);
        if(matcher.matches())
        {
            status=true;
        }
        else{
            status=false;
        }
    
    
    return status;
    
    
    
    
}
}