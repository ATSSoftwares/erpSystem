/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package erpsystem;
/**
 *
 * @author new climax
 */
public class Selecteditems {
     private String type;
    private String company;
   
    private String model;
     private String srate;
   private String prate;
   private String qunt;
   private String disc;
   private String total;
   private String dtotal;
   
    public  Selecteditems(String Type,String Company,String Model,String Srate,String Prate,String Qunt,String Disc,String Total,String dTotal)
    {
        
        this.type=Type;
       this.company=Company;
         this.model=Model;
         this.srate=Srate;
          this.prate=Prate;
           this.qunt=Qunt;
           this.disc=Disc;
         this.total=Total;
         this.dtotal=dTotal;
    }
     public String getType()
    {
        return type;
    }
      public String getComp()
    {
        return company;
    }
       public String getModel()
    {
        return model;
    } public String getSrate()
    {
        return srate;
    } public String getPrate()
    {
        return prate;
    } public String getQunt()
    {
        return qunt;
    }
     public String getDisc()
    {
        return disc;
    }
    
    
    public String getTotal()
    {
        return total;
    }
     public String getDtotal()
    {
        return dtotal;
    }
    
    
    
    
       
   
}
